/**
 * Type definitions for SSC (10th) Portal Backend
 */

// Junior College data structure from Excel
export interface JuniorCollegeData {
  collegeCode: string;
  collegeName: string;
  stream: string;           // Arts, Commerce, Science
  medium: string;           // English, Marathi, Hindi
  category: string;         // Open, SC, ST, OBC, etc.
  cutoffMarks: number;      // Cutoff marks out of 500 or 600
  maxMarks: number;         // Maximum marks (500 or 600)
  cutoffPercentage: number; // Calculated percentage
  year: string;
  round: string;            // Regular Round 1, 2, 3
  location: string;
  district: string;
  region: string;           // Mumbai, Pune, Nagpur, etc.
  collegeType: string;      // Government, Private, Aided
  status: string;
  fees?: number;
  intake?: number;
}

// SSC Recommendation request body
export interface SscRecommendationRequest {
  totalMarks: number;       // Marks obtained out of max
  maxMarks: number;         // Max marks (500 or 600)
  year: string;
  round: string;            // Regular Round
  category: string;
  streamPreference: string; // Arts, Commerce, Science
  location: string;
  medium?: string;          // Optional medium preference
}

// Processed junior college recommendation
export interface JuniorCollegeRecommendation {
  id: string;
  name: string;
  code: string;
  stream: string;
  medium: string;
  location: string;
  district: string;
  region: string;
  category: string;
  cutoffMarks: number;
  cutoffPercentage: number;
  userMarks: number;
  userPercentage: number;
  marksDifference: number;
  percentageDifference: number;
  collegeType: string;
  fees: string;
  seats: number;
  admissionChance: 'High' | 'Medium' | 'Low';
  round: string;
  year: string;
}

// SSC Filter options for frontend dropdown
export interface SscFilterOptions {
  years: string[];
  rounds: string[];
  categories: string[];
  streams: string[];
  locations: string[];
  regions: string[];
  mediums: string[];
}

// SSC API Response structure
export interface SscApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  metadata?: {
    totalResults: number;
    query: SscRecommendationRequest;
    timestamp: string;
  };
}
