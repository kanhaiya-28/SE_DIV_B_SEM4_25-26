import { Request, Response } from 'express';
import { sscRecommendationService } from '../services/sscRecommendationService.js';
import { sscDataService } from '../services/sscDataService.js';
import logger from '../utils/logger.js';
import type { 
  SscRecommendationRequest, 
  SscApiResponse, 
  JuniorCollegeRecommendation, 
  SscFilterOptions 
} from '../types/ssc.js';

/**
 * Get SSC junior college recommendations based on user criteria
 * POST /api/ssc/recommendations
 */
export const getSscRecommendations = async (
  req: Request<{}, SscApiResponse<JuniorCollegeRecommendation[]>, SscRecommendationRequest>,
  res: Response<SscApiResponse<JuniorCollegeRecommendation[]>>
): Promise<void> => {
  try {
    const requestBody = req.body;

    // Normalize round
    let round = requestBody.round;
    if (['1', '2', '3'].includes(round)) {
      round = `Round ${round}`;
    }

    const request: SscRecommendationRequest = {
      totalMarks: parseFloat(String(requestBody.totalMarks)),
      maxMarks: parseFloat(String(requestBody.maxMarks)) || 500,
      year: requestBody.year,
      round,
      category: requestBody.category,
      streamPreference: requestBody.streamPreference,
      location: requestBody.location,
      medium: requestBody.medium,
    };

    logger.info(`SSC Recommendation request received: ${JSON.stringify(request)}`);

    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
        message: 'Junior college data has not been loaded. Please try again later.',
      });
      return;
    }

    const recommendations = sscRecommendationService.getRecommendations(request);

    res.json({
      success: true,
      data: recommendations,
      metadata: {
        totalResults: recommendations.length,
        query: request,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    logger.error(`Error getting SSC recommendations: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get recommendations',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
};

/**
 * Get available SSC filter options
 * GET /api/ssc/filters
 */
export const getSscFilterOptions = async (
  _req: Request,
  res: Response<SscApiResponse<SscFilterOptions>>
): Promise<void> => {
  try {
    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
      });
      return;
    }

    const filterOptions = sscDataService.getFilterOptions();
    
    res.json({
      success: true,
      data: filterOptions,
    });
  } catch (error) {
    logger.error(`Error getting SSC filter options: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get filter options',
    });
  }
};

/**
 * SSC Health check endpoint
 * GET /api/ssc/health
 */
export const sscHealthCheck = async (
  _req: Request,
  res: Response
): Promise<void> => {
  const stats = sscRecommendationService.getStats();
  const isDataLoaded = sscDataService.isLoaded();

  res.json({
    success: true,
    status: isDataLoaded ? 'healthy' : 'data_not_loaded',
    data: {
      dataLoaded: isDataLoaded,
      ...stats,
      timestamp: new Date().toISOString(),
    },
  });
};

/**
 * Get all unique streams
 * GET /api/ssc/streams
 */
export const getSscStreams = async (
  _req: Request,
  res: Response
): Promise<void> => {
  try {
    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
      });
      return;
    }

    const filterOptions = sscDataService.getFilterOptions();
    
    res.json({
      success: true,
      data: filterOptions.streams,
    });
  } catch (error) {
    logger.error(`Error getting SSC streams: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get streams',
    });
  }
};

/**
 * Get all unique SSC locations
 * GET /api/ssc/locations
 */
export const getSscLocations = async (
  _req: Request,
  res: Response
): Promise<void> => {
  try {
    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
      });
      return;
    }

    const filterOptions = sscDataService.getFilterOptions();
    
    res.json({
      success: true,
      data: filterOptions.locations,
    });
  } catch (error) {
    logger.error(`Error getting SSC locations: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get locations',
    });
  }
};

/**
 * Get all unique SSC categories
 * GET /api/ssc/categories
 */
export const getSscCategories = async (
  _req: Request,
  res: Response
): Promise<void> => {
  try {
    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
      });
      return;
    }

    const filterOptions = sscDataService.getFilterOptions();
    
    res.json({
      success: true,
      data: filterOptions.categories,
    });
  } catch (error) {
    logger.error(`Error getting SSC categories: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get categories',
    });
  }
};

/**
 * Get all unique SSC regions
 * GET /api/ssc/regions
 */
export const getSscRegions = async (
  _req: Request,
  res: Response
): Promise<void> => {
  try {
    if (!sscDataService.isLoaded()) {
      res.status(503).json({
        success: false,
        error: 'SSC data not available',
      });
      return;
    }

    const filterOptions = sscDataService.getFilterOptions();
    
    res.json({
      success: true,
      data: filterOptions.regions,
    });
  } catch (error) {
    logger.error(`Error getting SSC regions: ${error}`);
    res.status(500).json({
      success: false,
      error: 'Failed to get regions',
    });
  }
};
