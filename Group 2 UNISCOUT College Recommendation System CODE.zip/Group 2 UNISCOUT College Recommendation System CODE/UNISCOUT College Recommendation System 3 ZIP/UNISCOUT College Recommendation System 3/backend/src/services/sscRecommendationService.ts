import { sscDataService } from './sscDataService.js';
import logger from '../utils/logger.js';
import type { 
  SscRecommendationRequest, 
  JuniorCollegeRecommendation, 
  JuniorCollegeData 
} from '../types/ssc.js';

class SscRecommendationService {
  /**
   * Get junior college recommendations based on user criteria
   */
  getRecommendations(request: SscRecommendationRequest): JuniorCollegeRecommendation[] {
    const { totalMarks, maxMarks, year, round, category, streamPreference, location, medium } = request;
    
    // Calculate user's percentage
    const userPercentage = (totalMarks / maxMarks) * 100;
    
    logger.info(`Processing SSC recommendation request: marks=${totalMarks}/${maxMarks} (${userPercentage.toFixed(2)}%), year=${year}, round=${round}, category=${category}, stream=${streamPreference}, location=${location}`);

    const allColleges = sscDataService.getAllColleges();
    
    if (allColleges.length === 0) {
      logger.warn('No SSC college data available');
      return [];
    }

    logger.info(`Total colleges in database: ${allColleges.length}`);

    // Filter colleges based on criteria
    const filteredColleges = allColleges.filter(college => {
      // Filter by year if specified
      if (year && college.year !== year) {
        return false;
      }

      // Filter by round if specified
      if (round) {
        const normalizedRound = this.normalizeRound(round);
        if (college.round !== normalizedRound) {
          return false;
        }
      }

      // Filter by category - match exact or Open category
      if (category) {
        const normalizedCategory = this.normalizeCategory(category);
        const collegeCategory = this.normalizeCategory(college.category);
        if (collegeCategory !== normalizedCategory && collegeCategory !== 'Open') {
          // If user is from reserved category, they can also see Open seats
          if (normalizedCategory !== 'Open') {
            return collegeCategory === normalizedCategory || collegeCategory === 'Open';
          }
          return collegeCategory === 'Open';
        }
      }

      // Filter by stream preference - STRICT matching
      if (streamPreference) {
        if (!this.streamMatches(streamPreference, college.stream)) {
          return false;
        }
      }

      // Filter by location preference
      if (location) {
        const normalizedLocation = location.toLowerCase();
        const collegeLocation = college.location.toLowerCase();
        const collegeDistrict = college.district.toLowerCase();
        const collegeRegion = college.region.toLowerCase();
        
        if (!collegeLocation.includes(normalizedLocation) && 
            !collegeDistrict.includes(normalizedLocation) &&
            !collegeRegion.includes(normalizedLocation) &&
            !normalizedLocation.includes(collegeLocation) &&
            !normalizedLocation.includes(collegeDistrict) &&
            !normalizedLocation.includes(collegeRegion)) {
          return false;
        }
      }

      // Filter by medium if specified
      if (medium) {
        const normalizedMedium = medium.toLowerCase();
        const collegeMedium = college.medium.toLowerCase();
        if (!collegeMedium.includes(normalizedMedium) && !normalizedMedium.includes(collegeMedium)) {
          return false;
        }
      }

      return true;
    });

    logger.info(`Filtered to ${filteredColleges.length} colleges`);

    // Calculate admission chances and sort by relevance
    const recommendations = filteredColleges
      .map(college => this.calculateRecommendation(college, totalMarks, maxMarks, userPercentage))
      .filter(rec => rec.admissionChance !== 'Low' || rec.percentageDifference >= -5) // Include colleges where user is slightly below cutoff
      .sort((a, b) => {
        // Sort by admission chance (High > Medium > Low)
        const chanceOrder = { High: 0, Medium: 1, Low: 2 };
        const chanceCompare = chanceOrder[a.admissionChance] - chanceOrder[b.admissionChance];
        if (chanceCompare !== 0) return chanceCompare;
        
        // Then by cutoff percentage (higher cutoff = better college)
        return b.cutoffPercentage - a.cutoffPercentage;
      })
      .slice(0, 100); // Limit to top 100 recommendations

    logger.info(`Returning ${recommendations.length} SSC recommendations`);
    return recommendations;
  }

  /**
   * Check if streams match
   */
  private streamMatches(preference: string, collegeStream: string): boolean {
    const streamMappings: Record<string, string[]> = {
      'science': ['science', 'sci', 'pcm', 'pcb', 'pcmb'],
      'commerce': ['commerce', 'comm', 'com'],
      'arts': ['arts', 'art', 'humanities'],
      'vocational': ['vocational', 'mcvc'],
      'bifocal': ['bifocal'],
    };

    const normalizedPreference = preference.toLowerCase().trim();
    const normalizedStream = collegeStream.toLowerCase().trim();

    // Direct match
    if (normalizedStream === normalizedPreference) {
      return true;
    }

    // Find which stream group the preference belongs to
    for (const [mainStream, variations] of Object.entries(streamMappings)) {
      if (normalizedPreference === mainStream || variations.includes(normalizedPreference)) {
        // Check if college stream is in the same group
        if (normalizedStream === mainStream || variations.includes(normalizedStream)) {
          return true;
        }
        // Also check if preference is contained in stream name
        if (normalizedStream.includes(mainStream)) {
          return true;
        }
      }
    }

    // Fallback: check containment
    return normalizedStream.includes(normalizedPreference) || normalizedPreference.includes(normalizedStream);
  }

  /**
   * Normalize category for comparison
   */
  private normalizeCategory(category: string): string {
    const categoryMap: Record<string, string> = {
      'open': 'Open',
      'general': 'Open',
      'gopen': 'Open',
      'sc': 'SC',
      'gsc': 'SC',
      'st': 'ST',
      'gst': 'ST',
      'obc': 'OBC',
      'gobc': 'OBC',
      'sebc': 'OBC',
      'nt': 'NT',
      'gnt': 'NT',
      'vjnt': 'VJ/NT',
      'sbc': 'SBC',
      'ews': 'EWS',
    };

    const normalized = category.toLowerCase().replace(/[^a-z]/g, '');
    return categoryMap[normalized] || category;
  }

  /**
   * Normalize round for comparison
   */
  private normalizeRound(round: string): string {
    const roundStr = round.toString().toLowerCase().trim();
    if (roundStr.includes('1') || roundStr.includes('first') || roundStr === 'i') {
      return 'Round 1';
    } else if (roundStr.includes('2') || roundStr.includes('second') || roundStr === 'ii') {
      return 'Round 2';
    } else if (roundStr.includes('3') || roundStr.includes('third') || roundStr === 'iii') {
      return 'Round 3';
    }
    return round;
  }

  /**
   * Calculate recommendation details for a college
   */
  private calculateRecommendation(
    college: JuniorCollegeData, 
    userMarks: number,
    maxMarks: number,
    userPercentage: number
  ): JuniorCollegeRecommendation {
    // Calculate differences
    const marksDifference = userMarks - (college.cutoffMarks * (maxMarks / college.maxMarks));
    const percentageDifference = userPercentage - college.cutoffPercentage;
    
    // Calculate admission chance based on percentage difference
    let admissionChance: 'High' | 'Medium' | 'Low';
    if (percentageDifference >= 5) {
      admissionChance = 'High';
    } else if (percentageDifference >= 0) {
      admissionChance = 'Medium';
    } else if (percentageDifference >= -3) {
      admissionChance = 'Low';
    } else {
      admissionChance = 'Low';
    }

    // Format fees
    const fees = college.fees 
      ? `₹${college.fees.toLocaleString('en-IN')}/year` 
      : '₹5,000 - 25,000/year';

    return {
      id: `${college.collegeCode}-${college.stream}-${college.category}`,
      name: college.collegeName,
      code: college.collegeCode,
      stream: college.stream,
      medium: college.medium,
      location: college.location,
      district: college.district,
      region: college.region,
      category: college.category,
      cutoffMarks: college.cutoffMarks,
      cutoffPercentage: Math.round(college.cutoffPercentage * 100) / 100,
      userMarks,
      userPercentage: Math.round(userPercentage * 100) / 100,
      marksDifference: Math.round(marksDifference * 100) / 100,
      percentageDifference: Math.round(percentageDifference * 100) / 100,
      collegeType: college.collegeType,
      fees,
      seats: college.intake || 120,
      admissionChance,
      round: college.round,
      year: college.year,
    };
  }

  /**
   * Get statistics about the recommendations
   */
  getStats(): { totalColleges: number; uniqueStreams: number; uniqueLocations: number; uniqueRegions: number } {
    return sscDataService.getStats();
  }
}

export const sscRecommendationService = new SscRecommendationService();
