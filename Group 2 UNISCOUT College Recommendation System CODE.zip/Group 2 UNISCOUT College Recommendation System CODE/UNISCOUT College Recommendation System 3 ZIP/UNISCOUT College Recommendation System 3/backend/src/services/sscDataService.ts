import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';
import logger from '../utils/logger.js';
import type { JuniorCollegeData, SscFilterOptions } from '../types/ssc.js';

interface ExcelRow {
  [key: string]: string | number | undefined;
}

class SscDataService {
  private collegeData: JuniorCollegeData[] = [];
  private isDataLoaded: boolean = false;
  private filterOptions: SscFilterOptions = {
    years: [],
    rounds: [],
    categories: [],
    streams: [],
    locations: [],
    regions: [],
    mediums: [],
  };

  /**
   * Initialize and load data from Excel file
   */
  async loadData(): Promise<void> {
    try {
      // Look for the SSC data file
      const possiblePaths = [
        path.resolve(__dirname, '../../../ALL_REGIONS_DATA_10TH.xlsx'),
        path.resolve(__dirname, '../../ALL_REGIONS_DATA_10TH.xlsx'),
        path.resolve(process.cwd(), 'ALL_REGIONS_DATA_10TH.xlsx'),
        path.resolve(process.cwd(), '../ALL_REGIONS_DATA_10TH.xlsx'),
      ];

      let filePath: string | null = null;
      for (const p of possiblePaths) {
        if (fs.existsSync(p)) {
          filePath = p;
          break;
        }
      }

      if (!filePath) {
        logger.warn('SSC data file not found. Tried paths: ' + possiblePaths.join(', '));
        logger.warn('SSC Portal will not be available.');
        return;
      }

      logger.info(`Loading SSC data from: ${filePath}`);

      const workbook = XLSX.readFile(filePath);
      
      // Log all sheet names
      logger.info(`Available sheets: ${workbook.SheetNames.join(', ')}`);
      
      // Load data from all sheets (different regions)
      let allData: ExcelRow[] = [];
      
      for (const sheetName of workbook.SheetNames) {
        const worksheet = workbook.Sheets[sheetName];
        const sheetData: ExcelRow[] = XLSX.utils.sheet_to_json(worksheet);
        
        // Add region info based on sheet name
        sheetData.forEach(row => {
          row['_sheetRegion'] = sheetName;
        });
        
        allData = [...allData, ...sheetData];
        logger.debug(`Loaded ${sheetData.length} rows from sheet: ${sheetName}`);
      }

      logger.info(`Found ${allData.length} total rows across all sheets`);

      // Log sample row to understand structure
      if (allData.length > 0) {
        logger.debug(`Sample row keys: ${Object.keys(allData[0]).join(', ')}`);
        logger.debug(`Sample row: ${JSON.stringify(allData[0])}`);
      }

      // Parse and normalize data
      this.collegeData = this.parseExcelData(allData);
      this.extractFilterOptions();
      this.isDataLoaded = true;

      logger.info(`Successfully loaded ${this.collegeData.length} junior college records`);
      logger.info(`Available streams: ${this.filterOptions.streams.join(', ')}`);
      logger.info(`Available locations: ${this.filterOptions.locations.length}`);
      logger.info(`Available categories: ${this.filterOptions.categories.join(', ')}`);
      logger.info(`Available regions: ${this.filterOptions.regions.join(', ')}`);
    } catch (error) {
      logger.error(`Failed to load SSC data: ${error}`);
      // Don't throw - just mark as not loaded
      this.isDataLoaded = false;
    }
  }

  /**
   * Parse Excel data and normalize column names
   */
  private parseExcelData(rawData: ExcelRow[]): JuniorCollegeData[] {
    const results: JuniorCollegeData[] = [];

    rawData.forEach((row, index) => {
      try {
        // Handle the actual column names from the data:
        // year, regular round no., college name, location, branch, category, total marks (cut off)
        
        const collegeCode = this.getColumnValue(row, ['College Code', 'college_code', 'CollegeCode', 'Jr College Code', 'Institute Code', 'Code']);
        const collegeName = this.getColumnValue(row, ['college name', 'College Name', 'college_name', 'CollegeName', 'Jr College Name', 'Name']);
        
        // "branch" in the data is actually the stream (Science, Commerce, Arts)
        const stream = this.getColumnValue(row, ['branch', 'Branch', 'Stream', 'stream', 'Course', 'Faculty']);
        
        const category = this.getColumnValue(row, ['category', 'Category', 'Seat Type', 'SeatType', 'Caste', 'Reservation']);
        
        // "total marks (cut off)" is the cutoff marks
        const cutoffRaw = this.getColumnValue(row, ['total marks (cut off)', 'total marks', 'Total Marks (Cut Off)', 'Cutoff', 'cutoff', 'Cut Off', 'Marks', 'Cut off Marks', 'Merit Marks']);
        
        const year = this.getColumnValue(row, ['year', 'Year', 'Academic Year', 'Admission Year']);
        
        // "regular round no." is the round number
        const round = this.getColumnValue(row, ['regular round no.', 'regular round', 'Regular Round No.', 'Round', 'round', 'Round No', 'Admission Round']);
        
        const location = this.getColumnValue(row, ['location', 'Location', 'City', 'Place', 'Taluka', 'Town', 'District']);
        const district = this.getColumnValue(row, ['District', 'district', 'Dist']) || location;
        
        // Region might not exist - default to sheet name or "Maharashtra"
        const region = this.getColumnValue(row, ['Region', 'region', 'Division', 'Board Region']) || String(row['_sheetRegion'] || 'Maharashtra');
        
        // Medium might not exist - default to "English"
        const medium = this.getColumnValue(row, ['Medium', 'medium', 'Language Medium', 'Teaching Medium']) || 'English';
        
        const collegeType = this.getColumnValue(row, ['Type', 'type', 'College Type', 'Institute Type', 'Status', 'Management']);
        const fees = this.getColumnValue(row, ['Fees', 'fees', 'Annual Fees', 'Tuition Fee', 'Fee']);
        const intake = this.getColumnValue(row, ['Intake', 'intake', 'Seats', 'Available Seats', 'Total Seats', 'Sanctioned Intake', 'Capacity']);

        // Parse cutoff marks
        let cutoffMarks = 0;
        if (cutoffRaw) {
          const parsed = parseFloat(cutoffRaw);
          if (!isNaN(parsed)) {
            cutoffMarks = parsed;
          }
        }

        // Max marks is 500 for SSC (10th standard)
        const maxMarks = 500;

        // Calculate percentage
        const cutoffPercentage = maxMarks > 0 ? (cutoffMarks / maxMarks) * 100 : 0;

        // Skip rows without essential data
        if (!collegeName) {
          return;
        }

        results.push({
          collegeCode: collegeCode || `JC${index}`,
          collegeName: this.normalizeText(collegeName),
          stream: this.normalizeStream(stream || 'Science'),
          medium: this.normalizeMedium(medium),
          category: this.normalizeCategory(category || 'Open'),
          cutoffMarks,
          maxMarks,
          cutoffPercentage: Math.round(cutoffPercentage * 100) / 100,
          year: year || '2024',
          round: this.normalizeRound(round || '1'),
          location: this.normalizeText(location || 'Maharashtra'),
          district: this.normalizeText(district || 'Maharashtra'),
          region: this.normalizeText(region),
          collegeType: collegeType || 'Private',
          status: 'Active',
          fees: fees ? parseFloat(fees) || undefined : undefined,
          intake: intake ? parseInt(intake) || 120 : 120,
        });
      } catch (error) {
        logger.warn(`Failed to parse SSC row ${index}: ${error}`);
      }
    });

    return results;
  }

  /**
   * Get column value with multiple possible column names
   */
  private getColumnValue(row: ExcelRow, possibleNames: string[]): string {
    for (const name of possibleNames) {
      // Check exact match
      if (row[name] !== undefined && row[name] !== null && row[name] !== '') {
        return String(row[name]).trim();
      }
      // Check case-insensitive match
      const lowerName = name.toLowerCase();
      for (const key of Object.keys(row)) {
        if (key.toLowerCase() === lowerName && row[key] !== undefined && row[key] !== null && row[key] !== '') {
          return String(row[key]).trim();
        }
      }
    }
    return '';
  }

  /**
   * Normalize text values
   */
  private normalizeText(text: string): string {
    return text
      .trim()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  /**
   * Normalize stream names to standard format
   */
  private normalizeStream(stream: string): string {
    const streamMapping: Record<string, string> = {
      'science': 'Science',
      'sci': 'Science',
      'pcm': 'Science',
      'pcb': 'Science',
      'pcmb': 'Science',
      'commerce': 'Commerce',
      'comm': 'Commerce',
      'com': 'Commerce',
      'arts': 'Arts',
      'art': 'Arts',
      'humanities': 'Arts',
      'general': 'General',
      'vocational': 'Vocational',
      'mcvc': 'MCVC',
      'bifocal': 'Bifocal',
    };

    const normalizedStream = stream.toLowerCase().trim();
    return streamMapping[normalizedStream] || this.normalizeText(stream);
  }

  /**
   * Normalize medium names
   */
  private normalizeMedium(medium: string): string {
    const mediumMapping: Record<string, string> = {
      'english': 'English',
      'eng': 'English',
      'marathi': 'Marathi',
      'mar': 'Marathi',
      'hindi': 'Hindi',
      'hin': 'Hindi',
      'urdu': 'Urdu',
      'semi-english': 'Semi-English',
      'semi english': 'Semi-English',
    };

    const normalizedMedium = medium.toLowerCase().trim();
    return mediumMapping[normalizedMedium] || this.normalizeText(medium);
  }

  /**
   * Normalize category values
   */
  private normalizeCategory(category: string): string {
    const categoryMapping: Record<string, string> = {
      'open': 'Open',
      'general': 'Open',
      'gopen': 'Open',
      'sc': 'SC',
      'gsc': 'SC',
      'st': 'ST',
      'gst': 'ST',
      'obc': 'OBC',
      'gobc': 'OBC',
      'sebc': 'OBC',
      'nt': 'NT',
      'gnt': 'NT',
      'ntb': 'NT-B',
      'ntc': 'NT-C',
      'ntd': 'NT-D',
      'vjnt': 'VJ/NT',
      'sbc': 'SBC',
      'ews': 'EWS',
    };

    const normalizedCategory = category.toLowerCase().trim().replace(/[^a-z]/g, '');
    return categoryMapping[normalizedCategory] || category.toUpperCase();
  }

  /**
   * Normalize round values
   */
  private normalizeRound(round: string): string {
    const roundStr = round.toString().toLowerCase().trim();
    if (roundStr.includes('1') || roundStr.includes('first') || roundStr === 'i') {
      return 'Round 1';
    } else if (roundStr.includes('2') || roundStr.includes('second') || roundStr === 'ii') {
      return 'Round 2';
    } else if (roundStr.includes('3') || roundStr.includes('third') || roundStr === 'iii') {
      return 'Round 3';
    }
    return 'Round 1';
  }

  /**
   * Extract unique filter options from data
   */
  private extractFilterOptions(): void {
    const yearsSet = new Set<string>();
    const roundsSet = new Set<string>();
    const categoriesSet = new Set<string>();
    const streamsSet = new Set<string>();
    const locationsSet = new Set<string>();
    const regionsSet = new Set<string>();
    const mediumsSet = new Set<string>();

    this.collegeData.forEach(college => {
      yearsSet.add(college.year);
      roundsSet.add(college.round);
      categoriesSet.add(college.category);
      streamsSet.add(college.stream);
      if (college.location) locationsSet.add(college.location);
      if (college.district) locationsSet.add(college.district);
      if (college.region) regionsSet.add(college.region);
      mediumsSet.add(college.medium);
    });

    this.filterOptions = {
      years: Array.from(yearsSet).sort().reverse(),
      rounds: Array.from(roundsSet).sort(),
      categories: Array.from(categoriesSet).sort(),
      streams: Array.from(streamsSet).sort(),
      locations: Array.from(locationsSet).sort(),
      regions: Array.from(regionsSet).sort(),
      mediums: Array.from(mediumsSet).sort(),
    };
  }

  /**
   * Get all loaded college data
   */
  getAllColleges(): JuniorCollegeData[] {
    return this.collegeData;
  }

  /**
   * Get filter options for frontend
   */
  getFilterOptions(): SscFilterOptions {
    return this.filterOptions;
  }

  /**
   * Check if data is loaded
   */
  isLoaded(): boolean {
    return this.isDataLoaded;
  }

  /**
   * Get stats about loaded data
   */
  getStats(): { totalColleges: number; uniqueStreams: number; uniqueLocations: number; uniqueRegions: number } {
    const streams = new Set(this.collegeData.map(c => c.stream));
    const locations = new Set(this.collegeData.map(c => c.location));
    const regions = new Set(this.collegeData.map(c => c.region));

    return {
      totalColleges: this.collegeData.length,
      uniqueStreams: streams.size,
      uniqueLocations: locations.size,
      uniqueRegions: regions.size,
    };
  }
}

// Singleton instance
export const sscDataService = new SscDataService();
