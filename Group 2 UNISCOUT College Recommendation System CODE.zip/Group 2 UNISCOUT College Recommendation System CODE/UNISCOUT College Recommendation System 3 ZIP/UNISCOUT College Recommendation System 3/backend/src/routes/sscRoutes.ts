import { Router } from 'express';
import {
  getSscRecommendations,
  getSscFilterOptions,
  sscHealthCheck,
  getSscStreams,
  getSscLocations,
  getSscCategories,
  getSscRegions,
} from '../controllers/sscController.js';
import {
  sscRecommendationValidation,
  handleValidationErrors,
} from '../middleware/sscValidation.js';

const router = Router();

/**
 * @route   GET /api/ssc/health
 * @desc    SSC Health check endpoint
 * @access  Public
 */
router.get('/health', sscHealthCheck);

/**
 * @route   GET /api/ssc/filters
 * @desc    Get all available SSC filter options
 * @access  Public
 */
router.get('/filters', getSscFilterOptions);

/**
 * @route   GET /api/ssc/streams
 * @desc    Get all unique streams (Science, Commerce, Arts)
 * @access  Public
 */
router.get('/streams', getSscStreams);

/**
 * @route   GET /api/ssc/locations
 * @desc    Get all unique SSC locations
 * @access  Public
 */
router.get('/locations', getSscLocations);

/**
 * @route   GET /api/ssc/categories
 * @desc    Get all unique SSC categories
 * @access  Public
 */
router.get('/categories', getSscCategories);

/**
 * @route   GET /api/ssc/regions
 * @desc    Get all unique SSC regions
 * @access  Public
 */
router.get('/regions', getSscRegions);

/**
 * @route   POST /api/ssc/recommendations
 * @desc    Get junior college recommendations based on SSC criteria
 * @access  Public
 */
router.post(
  '/recommendations',
  sscRecommendationValidation,
  handleValidationErrors,
  getSscRecommendations
);

export default router;
