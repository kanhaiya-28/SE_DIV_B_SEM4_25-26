import { Request, Response, NextFunction } from 'express';
import { validationResult, body, ValidationChain } from 'express-validator';
import logger from '../utils/logger.js';

// Validation rules for SSC recommendation request
export const sscRecommendationValidation: ValidationChain[] = [
  body('totalMarks')
    .notEmpty()
    .withMessage('Total marks is required')
    .isFloat({ min: 0 })
    .withMessage('Total marks must be a positive number'),
  
  body('maxMarks')
    .optional()
    .isFloat({ min: 100, max: 1000 })
    .withMessage('Max marks must be between 100 and 1000'),
  
  body('year')
    .notEmpty()
    .withMessage('Year is required')
    .isString()
    .withMessage('Year must be a string'),
  
  body('round')
    .notEmpty()
    .withMessage('Round is required')
    .isString()
    .withMessage('Round must be a string'),
  
  body('category')
    .notEmpty()
    .withMessage('Category is required')
    .isString()
    .withMessage('Category must be a string'),
  
  body('streamPreference')
    .notEmpty()
    .withMessage('Stream preference is required')
    .isString()
    .withMessage('Stream preference must be a string'),
  
  body('location')
    .optional()
    .isString()
    .withMessage('Location must be a string'),
  
  body('medium')
    .optional()
    .isString()
    .withMessage('Medium must be a string'),
];

// Middleware to handle validation errors
export const handleValidationErrors = (
  req: Request, 
  res: Response, 
  next: NextFunction
): void => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    logger.warn(`SSC Validation errors: ${JSON.stringify(errors.array())}`);
    res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors.array().map(err => ({
        field: 'path' in err ? err.path : 'unknown',
        message: err.msg,
      })),
    });
    return;
  }
  
  next();
};
