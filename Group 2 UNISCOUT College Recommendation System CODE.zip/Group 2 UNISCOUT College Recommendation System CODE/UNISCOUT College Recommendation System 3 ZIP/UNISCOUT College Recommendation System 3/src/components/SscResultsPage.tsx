import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  MapPin, 
  BookOpen, 
  TrendingUp, 
  TrendingDown, 
  Filter,
  GraduationCap,
  CheckCircle,
  AlertCircle,
  MinusCircle,
  Home,
  ChevronDown,
  X,
  Search,
  Sparkles,
  Award,
  ChevronRight,
  Users2
} from 'lucide-react';
import { JuniorCollegeRecommendation } from '../services/api';

interface SscResultsPageProps {
  colleges: JuniorCollegeRecommendation[];
  onBack: () => void;
  onHome: () => void;
}

type SortOption = 'chance' | 'cutoff-high' | 'cutoff-low' | 'name';
type FilterChance = 'all' | 'High' | 'Medium' | 'Low';

export function SscResultsPage({ colleges, onBack, onHome }: SscResultsPageProps) {
  const [sortBy, setSortBy] = useState<SortOption>('chance');
  const [filterChance, setFilterChance] = useState<FilterChance>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const processedColleges = useMemo(() => {
    let filtered = colleges;

    if (filterChance !== 'all') {
      filtered = colleges.filter(c => c.admissionChance === filterChance);
    }

    return [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'chance':
          const chanceOrder = { High: 0, Medium: 1, Low: 2 };
          const chanceCompare = chanceOrder[a.admissionChance] - chanceOrder[b.admissionChance];
          if (chanceCompare !== 0) return chanceCompare;
          return b.cutoffPercentage - a.cutoffPercentage;
        case 'cutoff-high':
          return b.cutoffPercentage - a.cutoffPercentage;
        case 'cutoff-low':
          return a.cutoffPercentage - b.cutoffPercentage;
        case 'name':
          return a.name.localeCompare(b.name);
        default:
          return 0;
      }
    });
  }, [colleges, sortBy, filterChance]);

  const stats = useMemo(() => ({
    total: colleges.length,
    high: colleges.filter(c => c.admissionChance === 'High').length,
    medium: colleges.filter(c => c.admissionChance === 'Medium').length,
    low: colleges.filter(c => c.admissionChance === 'Low').length,
  }), [colleges]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl" />
      </div>

      {/* Header */}
      <header className="relative z-50 border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-xl sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <motion.button
                onClick={onBack}
                className="flex items-center gap-2 px-4 py-2.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all font-medium"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                whileHover={{ x: -2 }}
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Back</span>
              </motion.button>

              <motion.button
                onClick={onHome}
                className="flex items-center gap-2 px-4 py-2.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all font-medium"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 }}
                whileHover={{ scale: 1.02 }}
              >
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline">Home</span>
              </motion.button>
            </div>

            <motion.div 
              className="flex items-center gap-3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div className="hidden sm:block">
                <span className="text-sm font-bold text-white">SSC Results</span>
                <p className="text-xs text-slate-500">{stats.total} Colleges Found</p>
              </div>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <StatCard
            label="Total Matches"
            value={stats.total}
            icon={<Sparkles className="w-5 h-5" />}
            color="purple"
          />
          <StatCard
            label="High Chance"
            value={stats.high}
            icon={<CheckCircle className="w-5 h-5" />}
            color="green"
            onClick={() => setFilterChance(filterChance === 'High' ? 'all' : 'High')}
            active={filterChance === 'High'}
          />
          <StatCard
            label="Medium Chance"
            value={stats.medium}
            icon={<MinusCircle className="w-5 h-5" />}
            color="yellow"
            onClick={() => setFilterChance(filterChance === 'Medium' ? 'all' : 'Medium')}
            active={filterChance === 'Medium'}
          />
          <StatCard
            label="Low Chance"
            value={stats.low}
            icon={<AlertCircle className="w-5 h-5" />}
            color="red"
            onClick={() => setFilterChance(filterChance === 'Low' ? 'all' : 'Low')}
            active={filterChance === 'Low'}
          />
        </motion.div>

        {/* Filters Bar */}
        <motion.div 
          className="flex flex-wrap items-center gap-3 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium transition-all ${
              showFilters 
                ? 'bg-purple-500 text-white' 
                : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
            }`}
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>

          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="h-11 px-4 pr-10 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm font-medium appearance-none cursor-pointer focus:outline-none focus:border-purple-500 transition-all"
            >
              <option value="chance" className="bg-slate-800">Sort by Chance</option>
              <option value="cutoff-high" className="bg-slate-800">Cutoff: High to Low</option>
              <option value="cutoff-low" className="bg-slate-800">Cutoff: Low to High</option>
              <option value="name" className="bg-slate-800">Name A-Z</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>

          {filterChance !== 'all' && (
            <button
              onClick={() => setFilterChance('all')}
              className="flex items-center gap-2 px-3 py-2 bg-purple-500/20 text-purple-400 rounded-lg text-sm font-medium"
            >
              <span>{filterChance} Chance</span>
              <X className="w-3 h-3" />
            </button>
          )}

          <div className="ml-auto text-sm text-slate-500">
            Showing {processedColleges.length} of {colleges.length} colleges
          </div>
        </motion.div>

        {/* College Cards */}
        {processedColleges.length > 0 ? (
          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {processedColleges.map((college, index) => (
                <motion.div
                  key={college.code + college.stream}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: index * 0.02 }}
                >
                  <CollegeCard 
                    college={college} 
                    isExpanded={expandedCard === college.code + college.stream}
                    onToggle={() => setExpandedCard(
                      expandedCard === college.code + college.stream 
                        ? null 
                        : college.code + college.stream
                    )}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <EmptyState onReset={() => setFilterChance('all')} />
        )}
      </main>
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ReactNode;
  color: 'purple' | 'green' | 'yellow' | 'red';
  onClick?: () => void;
  active?: boolean;
}

function StatCard({ label, value, icon, color, onClick, active }: StatCardProps) {
  const colors = {
    purple: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-400',
    green: 'from-green-500/20 to-emerald-500/20 border-green-500/30 text-green-400',
    yellow: 'from-yellow-500/20 to-amber-500/20 border-yellow-500/30 text-yellow-400',
    red: 'from-red-500/20 to-rose-500/20 border-red-500/30 text-red-400',
  };

  const activeColors = {
    purple: 'from-purple-500 to-pink-600 border-purple-400',
    green: 'from-green-500 to-emerald-600 border-green-400',
    yellow: 'from-yellow-500 to-amber-600 border-yellow-400',
    red: 'from-red-500 to-rose-600 border-red-400',
  };

  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-xl bg-gradient-to-br border transition-all ${
        active ? `${activeColors[color]} text-white` : colors[color]
      } ${onClick ? 'cursor-pointer hover:scale-[1.02]' : ''}`}
    >
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${active ? 'bg-white/20' : 'bg-slate-800/50'}`}>
          {icon}
        </div>
        <div className="text-left">
          <p className={`text-2xl font-bold ${active ? 'text-white' : ''}`}>{value}</p>
          <p className={`text-xs ${active ? 'text-white/70' : 'text-slate-500'}`}>{label}</p>
        </div>
      </div>
    </button>
  );
}

interface CollegeCardProps {
  college: JuniorCollegeRecommendation;
  isExpanded: boolean;
  onToggle: () => void;
}

function CollegeCard({ college, isExpanded, onToggle }: CollegeCardProps) {
  const chanceConfig = {
    High: { 
      color: 'text-green-400', 
      bg: 'bg-green-500/10 border-green-500/20',
      icon: <CheckCircle className="w-4 h-4" />,
      gradient: 'from-green-500 to-emerald-600'
    },
    Medium: { 
      color: 'text-yellow-400', 
      bg: 'bg-yellow-500/10 border-yellow-500/20',
      icon: <MinusCircle className="w-4 h-4" />,
      gradient: 'from-yellow-500 to-amber-600'
    },
    Low: { 
      color: 'text-red-400', 
      bg: 'bg-red-500/10 border-red-500/20',
      icon: <AlertCircle className="w-4 h-4" />,
      gradient: 'from-red-500 to-rose-600'
    },
  };

  const config = chanceConfig[college.admissionChance];

  return (
    <div 
      className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl overflow-hidden hover:border-slate-600 transition-all cursor-pointer"
      onClick={onToggle}
    >
      <div className="p-5">
        <div className="flex items-start gap-4">
          {/* Left: Chance Badge */}
          <div className={`flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br ${config.gradient} flex items-center justify-center shadow-lg`}>
            <span className="text-white font-bold text-lg">
              {college.admissionChance[0]}
            </span>
          </div>

          {/* Center: College Info */}
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-white mb-1 truncate">
              {college.name}
            </h3>
            <div className="flex flex-wrap items-center gap-2 text-sm text-slate-400">
              <span className="flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5" />
                {college.stream}
              </span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {college.location || 'Maharashtra'}
              </span>
            </div>
          </div>

          {/* Right: Stats */}
          <div className="flex-shrink-0 text-right hidden sm:block">
            <div className="flex items-center gap-1 justify-end mb-1">
              <Award className="w-4 h-4 text-purple-400" />
              <span className="text-lg font-bold text-white">{college.cutoffPercentage.toFixed(2)}%</span>
            </div>
            <p className="text-xs text-slate-500">Cutoff Percentage</p>
            <div className={`flex items-center gap-1 justify-end mt-2 ${
              college.percentageDifference > 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {college.percentageDifference > 0 
                ? <TrendingUp className="w-3.5 h-3.5" />
                : <TrendingDown className="w-3.5 h-3.5" />
              }
              <span className="text-sm font-medium">
                {college.percentageDifference > 0 ? '+' : ''}{college.percentageDifference.toFixed(2)}%
              </span>
            </div>
          </div>

          {/* Expand Icon */}
          <button className="flex-shrink-0 p-2 text-slate-400 hover:text-white transition-colors">
            <ChevronRight className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
          </button>
        </div>

        {/* Mobile Stats */}
        <div className="flex items-center gap-4 mt-4 sm:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-purple-400" />
            <span className="text-white font-semibold">{college.cutoffPercentage.toFixed(2)}%</span>
          </div>
          <div className={`flex items-center gap-1 ${
            college.percentageDifference > 0 ? 'text-green-400' : 'text-red-400'
          }`}>
            {college.percentageDifference > 0 
              ? <TrendingUp className="w-3.5 h-3.5" />
              : <TrendingDown className="w-3.5 h-3.5" />
            }
            <span className="text-sm font-medium">
              {college.percentageDifference > 0 ? '+' : ''}{college.percentageDifference.toFixed(2)}%
            </span>
          </div>
        </div>
      </div>

      {/* Expanded Details */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-slate-700"
          >
            <div className="p-5 bg-slate-800/30">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <DetailItem 
                  label="College Code" 
                  value={college.code} 
                  icon={<BookOpen className="w-4 h-4" />}
                />
                <DetailItem 
                  label="Category" 
                  value={college.category} 
                  icon={<Users2 className="w-4 h-4" />}
                />
                <DetailItem 
                  label="Medium" 
                  value={college.medium || 'English'} 
                  icon={<BookOpen className="w-4 h-4" />}
                />
                <DetailItem 
                  label="Region" 
                  value={college.region || 'N/A'} 
                  icon={<MapPin className="w-4 h-4" />}
                />
              </div>

              <div className={`mt-4 p-3 rounded-lg border ${config.bg}`}>
                <div className="flex items-center gap-2">
                  {config.icon}
                  <span className={`font-semibold ${config.color}`}>
                    {college.admissionChance} Admission Chance
                  </span>
                </div>
                <p className="text-sm text-slate-400 mt-1">
                  {college.admissionChance === 'High' && 'Your percentage is above the cutoff. Strong chances!'}
                  {college.admissionChance === 'Medium' && 'Your percentage is close to the cutoff. Good chances!'}
                  {college.admissionChance === 'Low' && 'Your percentage is below the cutoff. Consider as backup.'}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function DetailItem({ label, value, icon }: { label: string; value: string; icon: React.ReactNode }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-lg bg-slate-700/50 flex items-center justify-center text-slate-400 flex-shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-sm font-medium text-white">{value}</p>
      </div>
    </div>
  );
}

function EmptyState({ onReset }: { onReset: () => void }) {
  return (
    <div className="text-center py-16">
      <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-slate-800 flex items-center justify-center">
        <Search className="w-10 h-10 text-slate-600" />
      </div>
      <h3 className="text-xl font-bold text-white mb-2">No colleges found</h3>
      <p className="text-slate-400 mb-6">Try adjusting your filters to see more results</p>
      <button
        onClick={onReset}
        className="px-6 py-3 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-xl transition-colors"
      >
        Reset Filters
      </button>
    </div>
  );
}
